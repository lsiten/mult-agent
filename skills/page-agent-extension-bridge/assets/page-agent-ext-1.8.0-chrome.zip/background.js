var background = (function() {
  "use strict";
  function defineBackground(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  function handlePageControlMessage(message, sender, sendResponse) {
    executePageControlAction(
      message.action,
      message.payload,
      message.targetTabId,
      sender.tab?.id ?? null
    ).then((result2) => sendResponse(result2)).catch((error) => {
      sendResponse({
        success: false,
        error: error instanceof Error ? error.message : String(error)
      });
    });
    return true;
  }
  const PREFIX$1 = "[RemotePageController.background]";
  const debug$1 = console.debug.bind(console, `\x1B[90m${PREFIX$1}\x1B[0m`);
  async function executePageControlAction(action, payload, targetTabId, senderTabId = null) {
    if (action === "get_my_tab_id") {
      debug$1("get_my_tab_id", senderTabId);
      return { tabId: senderTabId };
    }
    try {
      return await chrome.tabs.sendMessage(targetTabId, {
        type: "PAGE_CONTROL",
        action,
        payload
      });
    } catch (error) {
      console.error(PREFIX$1, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
  const PREFIX = "[TabsController.background]";
  const debug = console.debug.bind(console, `\x1B[90m${PREFIX}\x1B[0m`);
  function handleTabControlMessage(message, sender, sendResponse) {
    executeTabAction(message.action, message.payload).then((result2) => sendResponse(result2)).catch((error) => {
      sendResponse({ error: error instanceof Error ? error.message : String(error) });
    });
    return true;
  }
  async function executeTabAction(action, payload) {
    switch (action) {
      case "get_active_tab": {
        debug("get_active_tab");
        const tabs = await chrome.tabs.query({ active: true });
        debug("get_active_tab: success", tabs);
        return { success: true, tab: tabs[0] };
      }
      case "get_tab_info": {
        debug("get_tab_info", payload);
        const tab = await chrome.tabs.get(payload.tabId);
        debug("get_tab_info: success", tab);
        return tab;
      }
      case "open_new_tab": {
        debug("open_new_tab", payload);
        const newTab = await chrome.tabs.create({ url: payload.url, active: false });
        debug("open_new_tab: success", newTab);
        return { success: true, tabId: newTab.id };
      }
      case "switch_to_tab": {
        debug("switch_to_tab", payload);
        const tabId = Number(payload.tabId);
        const tab = await chrome.tabs.update(tabId, { active: true });
        if (tab && typeof tab.windowId === "number") {
          await chrome.windows.update(tab.windowId, { focused: true });
        }
        return { success: true, tabId: tab?.id };
      }
      case "create_tab_group": {
        debug("create_tab_group", payload);
        const groupId = await chrome.tabs.group({
          tabIds: payload.tabIds,
          createProperties: { windowId: payload.windowId }
        });
        debug("create_tab_group: success", groupId);
        return { success: true, groupId };
      }
      case "update_tab_group": {
        debug("update_tab_group", payload);
        await chrome.tabGroups.update(payload.groupId, payload.properties);
        return { success: true };
      }
      case "add_tab_to_group": {
        debug("add_tab_to_group", payload);
        await chrome.tabs.group({ tabIds: payload.tabId, groupId: payload.groupId });
        return { success: true };
      }
      case "close_tab": {
        debug("close_tab", payload);
        await chrome.tabs.remove(payload.tabId);
        return { success: true };
      }
      case "get_window_tabs": {
        debug("get_window_tabs", payload);
        const tabs = await chrome.tabs.query({ windowId: payload.windowId });
        return { success: true, tabs };
      }
      default:
        return { error: `Unknown action: ${action}` };
    }
  }
  const tabEventPorts = /* @__PURE__ */ new Set();
  function broadcastTabEvent(message) {
    for (const port of tabEventPorts) {
      port.postMessage(message);
    }
  }
  function setupTabEventsPort() {
    chrome.runtime.onConnect.addListener((port) => {
      if (port.name !== "tab-events") return;
      debug("port connected", port.sender?.tab?.id ?? port.sender?.url);
      tabEventPorts.add(port);
      port.onDisconnect.addListener(() => {
        debug("port disconnected");
        tabEventPorts.delete(port);
      });
    });
    chrome.tabs.onCreated.addListener((tab) => {
      broadcastTabEvent({ action: "created", payload: { tab } });
    });
    chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
      broadcastTabEvent({ action: "removed", payload: { tabId, removeInfo } });
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      broadcastTabEvent({ action: "updated", payload: { tabId, changeInfo, tab } });
    });
  }
  const defaultConnectionConfig = {
    endpoint: "ws://127.0.0.1:18765",
    autoReconnectEnabled: true,
    periodicReconnectSec: 10,
    maxContinuousFailures: 30
  };
  async function getConnectionConfig() {
    const result2 = await chrome.storage.local.get("bridgeConnectionConfig");
    const stored = result2.bridgeConnectionConfig ?? {};
    return {
      ...defaultConnectionConfig,
      ...stored
    };
  }
  async function setConnectionConfig(next) {
    const prev = await getConnectionConfig();
    await chrome.storage.local.set({
      bridgeConnectionConfig: {
        ...prev,
        ...next
      }
    });
  }
  function getBackoffDelayMs(attempt) {
    const base = Math.min(3e4, 500 * 2 ** Math.max(0, attempt - 1));
    const jitter = Math.floor(Math.random() * 200);
    return base + jitter;
  }
  function shouldRunPeriodicReconnect(state, enabled) {
    if (!enabled) return false;
    return state === "idle" || state === "failed" || state === "degraded" || state === "reconnecting";
  }
  class BridgeClient {
    ws = null;
    state = "idle";
    reconnectAttempt = 0;
    periodicTimer = null;
    endpoint;
    webSocketFactory;
    onStateChange;
    constructor(options) {
      this.endpoint = options.endpoint;
      this.webSocketFactory = options.webSocketFactory ?? ((endpoint) => new WebSocket(endpoint));
      this.onStateChange = options.onStateChange;
    }
    /**
     * Check if manual connection is allowed from the current state
     */
    canManualConnect() {
      return this.state === "idle" || this.state === "failed" || this.state === "degraded";
    }
    /**
     * UNSAFE: Directly set the state for testing purposes only
     */
    __unsafeSetStateForTest(next) {
      this.state = next;
    }
    /**
     * Get the current connection state
     */
    getState() {
      return this.state;
    }
    /**
     * Start the client and initiate connection
     */
    async start() {
      const cfg = await getConnectionConfig();
      this.endpoint = cfg.endpoint || this.endpoint;
      await this.connectNow("startup");
      await this.startPeriodicReconnect();
    }
    /**
     * Manually initiate a connection
     */
    async manualConnect() {
      await this.connectNow("manual");
    }
    /**
     * Update connection configuration and restart periodic reconnect if needed
     */
    async setConnectionConfig(config) {
      await setConnectionConfig(config);
      if (config.periodicReconnectSec !== void 0) {
        await this.restartPeriodicReconnect();
      }
      if (config.endpoint !== void 0) {
        this.endpoint = config.endpoint;
      }
    }
    /**
     * Stop the client, clean up resources and close the connection
     */
    stop() {
      if (this.periodicTimer) {
        globalThis.clearInterval(this.periodicTimer);
        this.periodicTimer = null;
      }
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
      this.setState("idle");
      this.reconnectAttempt = 0;
    }
    /**
     * Set the internal state and notify subscribers
     */
    setState(next) {
      if (this.state !== next) {
        this.state = next;
        this.onStateChange?.(next);
      }
    }
    /**
     * Initiate a WebSocket connection immediately
     */
    async connectNow(_reason) {
      if (this.ws && (this.state === "connecting" || this.state === "authenticating" || this.state === "healthy")) {
        return;
      }
      this.setState("connecting");
      this.ws = this.webSocketFactory(this.endpoint);
      this.ws.onopen = () => {
        this.reconnectAttempt = 0;
        this.setState("healthy");
      };
      this.ws.onclose = () => {
        this.setState("failed");
        this.ws = null;
        void this.scheduleBackoffReconnect();
      };
      this.ws.onerror = () => {
        this.setState("failed");
      };
    }
    /**
     * Schedule a reconnection with exponential backoff
     */
    async scheduleBackoffReconnect() {
      const cfg = await getConnectionConfig();
      if (!cfg.autoReconnectEnabled) return;
      this.reconnectAttempt += 1;
      this.setState("reconnecting");
      const delay = getBackoffDelayMs(this.reconnectAttempt);
      globalThis.setTimeout(() => {
        void this.connectNow("backoff");
      }, delay);
    }
    /**
     * Start the periodic reconnect timer
     */
    async startPeriodicReconnect() {
      const cfg = await getConnectionConfig();
      if (this.periodicTimer) return;
      this.periodicTimer = globalThis.setInterval(() => {
        if (shouldRunPeriodicReconnect(this.state, cfg.autoReconnectEnabled)) {
          void this.connectNow("periodic");
        }
      }, cfg.periodicReconnectSec * 1e3);
    }
    /**
     * Restart the periodic reconnect timer with fresh configuration
     */
    async restartPeriodicReconnect() {
      if (this.periodicTimer) {
        globalThis.clearInterval(this.periodicTimer);
        this.periodicTimer = null;
      }
      await this.startPeriodicReconnect();
    }
  }
  function createBridgeRuntime(config = {}) {
    const endpoint = config.endpoint ?? "ws://127.0.0.1:18765";
    const client = new BridgeClient({ endpoint });
    return {
      async start() {
        try {
          await client.start();
        } catch (error) {
          console.error("[BridgeRuntime] Failed to start bridge", error);
          throw error;
        }
      },
      async manualConnect() {
        try {
          await client.manualConnect();
        } catch (error) {
          console.error("[BridgeRuntime] Manual connect failed", error);
          throw error;
        }
      }
    };
  }
  const definition = defineBackground(() => {
    console.log("[Background] Service Worker started");
    const runtime = createBridgeRuntime();
    void runtime.start().catch((error) => {
      console.error("[Background] Failed to start bridge runtime", error);
    });
    setupTabEventsPort();
    chrome.storage.local.get("PageAgentExtUserAuthToken").then((result2) => {
      if (result2.PageAgentExtUserAuthToken) return;
      const userAuthToken = crypto.randomUUID();
      chrome.storage.local.set({ PageAgentExtUserAuthToken: userAuthToken });
    });
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message?.type === "BRIDGE_MANUAL_CONNECT") {
        void runtime.manualConnect().then(() => sendResponse({ ok: true })).catch((error) => {
          console.error("[Background] Manual connect failed", error);
          sendResponse({
            ok: false,
            error: error instanceof Error ? error.message : "Unknown error"
          });
        });
        return true;
      } else if (message.type === "TAB_CONTROL") {
        return handleTabControlMessage(message, sender, sendResponse);
      } else if (message.type === "PAGE_CONTROL") {
        return handlePageControlMessage(message, sender, sendResponse);
      } else {
        sendResponse({ error: "Unknown message type" });
        return;
      }
    });
    chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
      if (message.type === "OPEN_HUB") {
        openOrFocusHubTab(message.wsPort).then(() => {
          if (sender.tab?.id) chrome.tabs.remove(sender.tab.id);
          sendResponse({ ok: true });
        });
        return true;
      }
    });
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
    });
  });
  async function openOrFocusHubTab(wsPort) {
    const hubUrl = chrome.runtime.getURL("hub.html");
    const existing = await chrome.tabs.query({ url: `${hubUrl}*` });
    if (existing.length > 0 && existing[0].id) {
      await chrome.tabs.update(existing[0].id, {
        active: true,
        url: `${hubUrl}?ws=${wsPort}`
      });
      return;
    }
    await chrome.tabs.create({ url: `${hubUrl}?ws=${wsPort}`, pinned: true });
  }
  function initPlugins() {
  }
  globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  function print(method, ...args) {
    return;
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  let result;
  try {
    initPlugins();
    result = definition.main();
    if (result instanceof Promise) console.warn("The background's main() function return a promise, but it must be synchronous");
  } catch (err) {
    logger.error("The background crashed on startup!");
    throw err;
  }
  var background_entrypoint_default = result;
  return background_entrypoint_default;
})();
